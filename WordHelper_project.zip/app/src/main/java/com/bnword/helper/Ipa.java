package com.bnword.helper;

/** Converts an English IPA transcription (e.g. /ˈhæpinəs/) to Bengali spelling. */
final class Ipa {
    private static final String HAS = "\u09CD";

    // token, consonant-form (null if vowel)
    private static final String[][] CONS = {
        {"t\u0283", "\u099A"}, {"d\u0292", "\u099C"}, {"\u0283", "\u09B6"}, {"\u0292", "\u099C"},
        {"\u03B8", "\u09A5"}, {"\u00F0", "\u09A6"}, {"\u014B", "\u0982"},
        {"p", "\u09AA"}, {"b", "\u09AC"}, {"t", "\u099F"}, {"d", "\u09A1"}, {"k", "\u0995"},
        {"g", "\u0997"}, {"\u0261", "\u0997"}, {"f", "\u09AB"}, {"v", "\u09AD"}, {"s", "\u09B8"},
        {"z", "\u099C"}, {"h", "\u09B9"}, {"m", "\u09AE"}, {"n", "\u09A8"}, {"l", "\u09B2"},
        {"\u026B", "\u09B2"}, {"r", "\u09B0"}, {"\u0279", "\u09B0"}, {"\u027E", "\u099F"},
    };

    // vowels: token, dependent form, independent form
    private static final String[][] VOW = {
        {"e\u026A", "\u09C7", "\u098F"},            // eɪ
        {"a\u026A", "\u09BE\u0987", "\u0986\u0987"}, // aɪ
        {"\u0254\u026A", "\u09DF", "\u0985\u09DF"},  // ɔɪ
        {"a\u028A", "\u09BE\u0989", "\u0986\u0989"}, // aʊ
        {"o\u028A", "\u09CB", "\u0993"},             // oʊ
        {"\u0259\u028A", "\u09CB", "\u0993"},        // əʊ
        {"\u00E6", "\u09CD\u09AF\u09BE", "\u0985\u09CD\u09AF\u09BE"}, // æ
        {"\u0251", "\u09BE", "\u0986"},              // ɑ
        {"\u0252", "", "\u0985"},                    // ɒ
        {"\u0254", "", "\u0985"},                    // ɔ
        {"\u028C", "\u09BE", "\u0986"},              // ʌ
        {"\u026A", "\u09BF", "\u0987"},              // ɪ
        {"i", "\u09BF", "\u0987"},
        {"\u025B", "\u09C7", "\u098F"},              // ɛ
        {"e", "\u09C7", "\u098F"},
        {"\u028A", "\u09C1", "\u0989"},              // ʊ
        {"u", "\u09C1", "\u0989"},
        {"\u0259", "\u09C7", "\u0986"},              // ə
        {"\u025A", "R", "R"}, {"\u025D", "R", "R"}, {"\u025C", "R", "R"}, // ɚ ɝ ɜ  (vowel া + র)
        {"a", "\u09BE", "\u0986"},
        {"o", "\u09CB", "\u0993"},
    };

    static String toBengali(String ipa) {
        if (ipa == null) return null;
        String s = ipa.replaceAll("[/\\[\\]ˈˌ\u02D0\\.\\(\\)\u0300-\u036F\u02B0\u02B2]", "")
                      .replace("ɡ", "g").replace("ɹ", "r").trim();
        if (s.isEmpty()) return null;

        StringBuilder out = new StringBuilder();
        boolean lastCons = false;   // last emitted unit is a bare consonant (inherent vowel pending)
        boolean atStart = true;     // nothing emitted yet / after a vowel -> use independent vowels
        boolean afterVowel = false;
        boolean noHas = false;
        boolean yaBase = false;  // last unit ends in য় (acts like a consonant for vowel signs)
        boolean lastW = false;
        int i = 0;
        while (i < s.length()) {
            // semi-vowels
            char c = s.charAt(i);
            if (c == 'w') {
                out.append(lastCons ? HAS : "").append(atStart || afterVowel ? "\u0993\u09DF" : "\u09CB\u09DF");
                if (!(atStart || afterVowel)) { /* consonant-w after consonant: treat as ওয় */ }
                lastCons = false; yaBase = true; lastW = true; atStart = false; afterVowel = false; i++; continue;
            }
            if (c == 'j') {
                if (lastCons) out.append("\u09BF\u09DF"); else out.append("\u0987\u09DF");
                lastCons = false; yaBase = true; lastW = false; atStart = false; afterVowel = false; i++; continue;
            }
            // vowels
            boolean matched = false;
            for (String[] v : VOW) {
                if (s.startsWith(v[0], i)) {
                    i += v[0].length();
                    boolean indep = atStart || afterVowel || !lastCons && out.length() == 0;
                    boolean cons = lastCons || yaBase;
                    if (lastW && (v[0].equals("\u0254") || v[0].equals("\u0252"))) { out.append("\u09BE"); lastCons = false; yaBase = false; lastW = false; afterVowel = true; atStart = false; matched = true; break; }
                    if (v[1].equals("R")) {
                        out.append(cons ? "\u09BE" : "\u0986").append("\u09B0");
                        lastCons = true; afterVowel = false; atStart = false;
                    } else if (v[0].equals("\u0259") && !indep && isSyllabicEnd(s, i)) {
                        noHas = true; lastCons = false; afterVowel = true; atStart = false; // silent schwa before final l/n/m
                    } else {
                        out.append(cons ? v[1] : v[2]);
                        lastCons = false; afterVowel = true; atStart = false;
                    }
                    yaBase = false; lastW = false;
                    matched = true;
                    break;
                }
            }
            if (matched) continue;
            // consonants
            for (String[] k : CONS) {
                if (s.startsWith(k[0], i)) {
                    i += k[0].length();
                    if (k[1].equals("\u0982")) { out.append(k[1]); lastCons = false; }
                    else {
                        if (lastCons && !noHas) out.append(HAS);
                        String form = k[1];
                        if (k[0].equals("z") && i >= s.length()) form = "\u09B8"; // final z -> স
                        out.append(form);
                        lastCons = true;
                    }
                    noHas = false; yaBase = false; lastW = false; atStart = false; afterVowel = false;
                    matched = true;
                    break;
                }
            }
            if (!matched) i++; // unknown symbol -> skip
        }
        String r = out.toString();
        return r.isEmpty() ? null : r;
    }

    private static boolean isSyllabicEnd(String s, int idx) {
        return idx == s.length() - 1 && "lnm".indexOf(s.charAt(idx)) >= 0;
    }
}
