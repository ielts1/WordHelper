package com.bnword.helper;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class WordAccessibilityService extends AccessibilityService {

    static volatile boolean connected = false;
    private static WordAccessibilityService instance;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService net = Executors.newSingleThreadExecutor();
    private final Map<String, String> meaningCache = new HashMap<>();
    private final Map<String, String> pronCache = new HashMap<>();
    private TextToSpeech tts;
    private boolean ttsReady = false;

    private WindowManager wm;
    private LinearLayout popup;
    private TextView tvWord, tvPron, tvMean;
    private String currentWord = "";
    private int token = 0;
    private Runnable pending;

    static void dismissIfShowing() {
        if (instance != null) instance.ui.post(instance::hidePopup);
    }

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        connected = true;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        Dict.load(this);
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(Locale.US);
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
                tts.setSpeechRate(0.85f);
                tts.setPitch(1.0f);
            }
        });
        ToggleTileService.refresh(this);
    }

    @Override public boolean onUnbind(android.content.Intent intent) {
        connected = false;
        instance = null;
        hidePopup();
        ToggleTileService.refresh(this);
        return super.onUnbind(intent);
    }

    @Override public void onDestroy() {
        connected = false;
        instance = null;
        hidePopup();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        net.shutdownNow();
        super.onDestroy();
    }

    @Override public void onInterrupt() { }

    private String lastShown = "";
    private boolean scanScheduled = false;
    private final Runnable scanRun = () -> {
        scanScheduled = false;
        if (!ToggleTileService.isOn(this)) return;
        String sel = null;
        try { sel = findSelectedText(getRootInActiveWindow()); } catch (Exception ignored) { }
        if (sel == null) { lastShown = ""; return; }
        if (sel.equals(lastShown)) return;
        schedule(sel);
    };

    private void schedule(final String sel) {
        if (pending != null) ui.removeCallbacks(pending);
        pending = () -> showFor(sel);
        ui.postDelayed(pending, 450); // wait until the user stops dragging the selection handles
    }

    /** Called from the text-selection menu item (PROCESS_TEXT). */
    static boolean showExternal(String raw) {
        final WordAccessibilityService me = instance;
        if (me == null) return false;
        final String sel = clean(raw);
        if (sel == null) return true;
        me.ui.post(() -> { me.lastShown = ""; me.showFor(sel); });
        return true;
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent ev) {
        if (ev == null) return;
        int t = ev.getEventType();
        if (t != AccessibilityEvent.TYPE_VIEW_TEXT_SELECTION_CHANGED
                && t != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) return;
        if (!ToggleTileService.isOn(this)) return;
        CharSequence pkg = ev.getPackageName();
        if (pkg != null && pkg.toString().equals(getPackageName())) return;

        if (t == AccessibilityEvent.TYPE_VIEW_TEXT_SELECTION_CHANGED) {
            String sel = extractSelection(ev);
            if (sel != null) { schedule(sel); return; }
        }
        // Browsers (Chrome etc.) often do not send selection details in the event:
        // look through the screen for the selected text instead (throttled).
        if (!scanScheduled) {
            scanScheduled = true;
            ui.postDelayed(scanRun, 600);
        }
    }

    static String clean(String raw) {
        if (raw == null) return null;
        String sel = raw.trim().replaceAll("^[^A-Za-z]+|[^A-Za-z]+$", "");
        if (sel.isEmpty() || sel.length() > 60) return null;
        if (!sel.matches(".*[A-Za-z].*")) return null;
        if (sel.split("\\s+").length > 6) return null;
        return sel;
    }

    private String extractSelection(AccessibilityEvent ev) {
        try {
            CharSequence text = null;
            int s = ev.getFromIndex(), e = ev.getToIndex();
            AccessibilityNodeInfo src = ev.getSource();
            if (src != null) {
                if (src.isPassword()) return null;
                text = src.getText();
                int ns = src.getTextSelectionStart(), ne = src.getTextSelectionEnd();
                if (ns >= 0 && ne >= 0 && ns != ne) { s = ns; e = ne; }
            }
            if (text == null && ev.getText() != null && !ev.getText().isEmpty()) text = ev.getText().get(0);
            if (text == null) return null;
            if (s > e) { int t = s; s = e; e = t; }
            if (s < 0 || e > text.length() || s == e) return null;
            return clean(text.subSequence(s, e).toString());
        } catch (Exception ex) {
            return null;
        }
    }

    private String findSelectedText(AccessibilityNodeInfo root) {
        if (root == null) return null;
        java.util.ArrayDeque<AccessibilityNodeInfo> q = new java.util.ArrayDeque<>();
        q.add(root);
        int count = 0;
        while (!q.isEmpty() && count < 2500) {
            AccessibilityNodeInfo n = q.poll();
            count++;
            if (n == null) continue;
            try {
                if (!n.isPassword()) {
                    CharSequence tx = n.getText();
                    int ns = n.getTextSelectionStart(), ne = n.getTextSelectionEnd();
                    if (tx != null && ns >= 0 && ne >= 0 && ns != ne) {
                        int s = Math.min(ns, ne), e = Math.max(ns, ne);
                        if (e <= tx.length()) {
                            String c = clean(tx.subSequence(s, e).toString());
                            if (c != null) return c;
                        }
                    }
                }
                for (int i = 0; i < n.getChildCount(); i++) {
                    AccessibilityNodeInfo ch = n.getChild(i);
                    if (ch != null) q.add(ch);
                }
            } catch (Exception ignored) { }
        }
        return null;
    }

    // ---------------------------------------------------------------- popup

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private void ensurePopup() {
        if (popup != null) return;
        popup = new LinearLayout(this);
        popup.setOrientation(LinearLayout.VERTICAL);
        popup.setPadding(dp(14), dp(8), dp(8), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), Color.parseColor("#CBD5E0"));
        popup.setBackground(bg);
        popup.setElevation(dp(10));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        tvWord = new TextView(this);
        tvWord.setTextSize(17);
        tvWord.setTextColor(Color.parseColor("#2B6CB0"));
        tvWord.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams wlp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        wlp.setMarginEnd(dp(12));
        tvWord.setMaxWidth(dp(200));
        row.addView(tvWord, wlp);

        ImageButton mic = new ImageButton(this);
        mic.setImageResource(R.drawable.ic_mic);
        mic.setBackgroundColor(Color.TRANSPARENT);
        mic.setContentDescription("Pronounce");
        mic.setOnClickListener(v -> speak(currentWord));
        row.addView(mic, new LinearLayout.LayoutParams(dp(36), dp(36)));

        ImageButton close = new ImageButton(this);
        close.setImageResource(R.drawable.ic_close);
        close.setBackgroundColor(Color.TRANSPARENT);
        close.setContentDescription("Close");
        close.setOnClickListener(v -> hidePopup());
        row.addView(close, new LinearLayout.LayoutParams(dp(36), dp(36)));

        popup.addView(row);

        tvPron = new TextView(this);
        tvPron.setTextSize(14);
        tvPron.setMaxWidth(dp(260));
        tvPron.setTextColor(Color.parseColor("#718096"));
        popup.addView(tvPron);

        tvMean = new TextView(this);
        tvMean.setTextSize(16);
        tvMean.setMaxWidth(dp(260));
        tvMean.setTextColor(Color.parseColor("#2D3748"));
        tvMean.setPadding(0, dp(2), dp(6), 0);
        popup.addView(tvMean);

        // tap anywhere outside the box -> close
        popup.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_OUTSIDE) { hidePopup(); return true; }
            return false;
        });
    }

    private void showFor(String text) {
        if (text.equals(lastShown) && popup != null && popup.getParent() != null) return;
        lastShown = text;
        ensurePopup();
        currentWord = text;
        final int my = ++token;
        boolean single = !text.contains(" ");

        tvWord.setText(text);
        String[] v = Dict.vocab(text);
        String pron;
        if (single) pron = Dict.pron(text);
        else if (v != null) pron = v[0];
        else {
            StringBuilder pb = new StringBuilder();
            for (String w : text.split("\\s+")) { String x = Dict.pron(w); if (!x.isEmpty()) pb.append(x).append(' '); }
            pron = pb.toString().trim();
        }
        tvPron.setText(pron.isEmpty() ? "" : "উচ্চারণ: " + pron);
        tvPron.setVisibility(pron.isEmpty() ? android.view.View.GONE : android.view.View.VISIBLE);

        String key = text.toLowerCase(Locale.ROOT);
        String cached = v != null ? v[1] : meaningCache.get(key);
        tvMean.setText(cached != null ? cached : "অর্থ খুঁজছি…");
        final String pron0 = pron;
        if (cached != null) { String cp0 = pronCache.get(key); SavedWords.add(this, text, cp0 != null ? cp0 : pron0, cached); }

        if (popup.getParent() == null) {
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
            lp.y = dp(90);
            try { wm.addView(popup, lp); } catch (Exception ignored) { return; }
        }

        speak(text);

        final String q = text;
        if (cached == null) {
            net.execute(() -> {
                String m = fetchMeaning(q);
                ui.post(() -> {
                    if (m != null) {
                        meaningCache.put(key, m);
                        String pp = pronCache.get(key);
                        SavedWords.add(WordAccessibilityService.this, q, pp != null ? pp : pron0, m);
                    }
                    if (my != token || popup == null) return;
                    if (m != null) tvMean.setText(m);
                    else tvMean.setText("অর্থ পাওয়া যায়নি (ইন্টারনেট চেক করুন)");
                });
            });
        }
        if (single && !Dict.curated(text)) {
            final String k2 = key;
            String cp = pronCache.get(k2);
            if (cp != null) { tvPron.setText("উচ্চারণ: " + cp); tvPron.setVisibility(android.view.View.VISIBLE); }
            else net.execute(() -> {
                String bn = fetchIpaBengali(q);
                if (bn == null) return;
                ui.post(() -> {
                    pronCache.put(k2, bn);
                    String mm = meaningCache.get(k2);
                    if (mm != null) SavedWords.add(WordAccessibilityService.this, q, bn, mm);
                    if (my != token || popup == null) return;
                    tvPron.setText("উচ্চারণ: " + bn);
                    tvPron.setVisibility(android.view.View.VISIBLE);
                });
            });
        }
    }

    private void hidePopup() {
        token++;
        if (pending != null) { ui.removeCallbacks(pending); pending = null; }
        if (popup != null && popup.getParent() != null) {
            try { wm.removeView(popup); } catch (Exception ignored) { }
        }
        if (tts != null) tts.stop();
    }

    private void speak(String text) {
        if (tts == null || !ttsReady || text == null || text.isEmpty()) return;
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "wh");
    }

    // ---------------------------------------------------------------- meaning

    private String fetchMeaning(String q) {
        String m = googleMeaning(q);
        if (m == null || m.equalsIgnoreCase(q)) m = myMemory(q);
        if (m != null && m.equalsIgnoreCase(q)) m = null;
        return m;
    }

    private String httpGet(String u) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setConnectTimeout(6000);
        c.setReadTimeout(8000);
        c.setRequestProperty("User-Agent", "Mozilla/5.0");
        try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            return sb.toString();
        } finally {
            c.disconnect();
        }
    }

    private String googleMeaning(String q) {
        try {
            String u = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=bn&dt=t&dt=bd&q="
                    + URLEncoder.encode(q, "UTF-8");
            JSONArray root = new JSONArray(httpGet(u));
            JSONArray seg = root.getJSONArray(0);
            StringBuilder main = new StringBuilder();
            for (int i = 0; i < seg.length(); i++) {
                JSONArray part = seg.optJSONArray(i);
                if (part != null && !part.isNull(0)) main.append(part.getString(0));
            }
            String result = main.toString().trim();
            if (result.isEmpty()) return null;
            // extra meanings for single words (dictionary section)
            if (!q.contains(" ") && root.length() > 1 && !root.isNull(1)) {
                JSONArray dict = root.optJSONArray(1);
                if (dict != null && dict.length() > 0) {
                    JSONArray first = dict.optJSONArray(0);
                    JSONArray terms = first != null ? first.optJSONArray(1) : null;
                    if (terms != null) {
                        StringBuilder sb = new StringBuilder(result);
                        int added = 0;
                        for (int i = 0; i < terms.length() && added < 3; i++) {
                            String t = terms.optString(i, "").trim();
                            if (!t.isEmpty() && !result.contains(t)) { sb.append(", ").append(t); added++; }
                        }
                        result = sb.toString();
                    }
                }
            }
            return result;
        } catch (Exception e) {
            return null;
        }
    }

    private String fetchIpaBengali(String word) {
        try {
            String u = "https://api.dictionaryapi.dev/api/v2/entries/en/"
                    + URLEncoder.encode(word.toLowerCase(Locale.ROOT), "UTF-8");
            JSONArray arr = new JSONArray(httpGet(u));
            org.json.JSONObject e0 = arr.getJSONObject(0);
            String ipa = null, first = null;
            JSONArray ph = e0.optJSONArray("phonetics");
            if (ph != null) {
                for (int i = 0; i < ph.length(); i++) {
                    org.json.JSONObject o = ph.optJSONObject(i);
                    if (o == null) continue;
                    String t = o.optString("text", "");
                    if (t.isEmpty()) continue;
                    if (first == null) first = t;
                    if (o.optString("audio", "").contains("-us")) { ipa = t; break; }
                }
            }
            if (ipa == null) ipa = first;
            if (ipa == null) ipa = e0.optString("phonetic", "");
            if (ipa == null || ipa.isEmpty()) return null;
            return Ipa.toBengali(ipa);
        } catch (Exception e) {
            return null;
        }
    }

    private String myMemory(String q) {
        try {
            String u = "https://api.mymemory.translated.net/get?langpair=en|bn&q=" + URLEncoder.encode(q, "UTF-8");
            org.json.JSONObject o = new org.json.JSONObject(httpGet(u));
            String t = o.getJSONObject("responseData").optString("translatedText", "").trim();
            return t.isEmpty() ? null : t;
        } catch (Exception e) {
            return null;
        }
    }
}
