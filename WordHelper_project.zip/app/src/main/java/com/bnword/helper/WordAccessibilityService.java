package com.bnword.helper;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class WordAccessibilityService extends AccessibilityService {

    static volatile boolean connected = false;
    private static WordAccessibilityService instance;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService net = Executors.newSingleThreadExecutor();
    private final Map<String, String> meaningCache = new HashMap<>();
    private TextToSpeech tts;
    private boolean ttsReady = false;

    private WindowManager wm;
    private LinearLayout popup;
    private TextView tvWord, tvPron, tvMean;
    private String currentWord = "";
    private int token = 0;
    private Runnable pending;

    static void dismissIfShowing() {
        if (instance != null) instance.ui.post(instance::hidePopup);
    }

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        connected = true;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        Dict.load(this);
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(Locale.US);
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
            }
        });
        ToggleTileService.refresh(this);
    }

    @Override public boolean onUnbind(android.content.Intent intent) {
        connected = false;
        instance = null;
        hidePopup();
        ToggleTileService.refresh(this);
        return super.onUnbind(intent);
    }

    @Override public void onDestroy() {
        connected = false;
        instance = null;
        hidePopup();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        net.shutdownNow();
        super.onDestroy();
    }

    @Override public void onInterrupt() { }

    @Override public void onAccessibilityEvent(AccessibilityEvent ev) {
        if (ev == null || ev.getEventType() != AccessibilityEvent.TYPE_VIEW_TEXT_SELECTION_CHANGED) return;
        if (!ToggleTileService.isOn(this)) return;
        CharSequence pkg = ev.getPackageName();
        if (pkg != null && pkg.toString().equals(getPackageName())) return;

        final String sel = extractSelection(ev);
        if (pending != null) ui.removeCallbacks(pending);
        if (sel == null) return;
        pending = () -> showFor(sel);
        ui.postDelayed(pending, 450); // wait until the user stops dragging the selection handles
    }

    private String extractSelection(AccessibilityEvent ev) {
        try {
            CharSequence text = null;
            int s = ev.getFromIndex(), e = ev.getToIndex();
            AccessibilityNodeInfo src = ev.getSource();
            if (src != null) {
                if (src.isPassword()) return null;
                text = src.getText();
                int ns = src.getTextSelectionStart(), ne = src.getTextSelectionEnd();
                if (ns >= 0 && ne >= 0 && ns != ne) { s = ns; e = ne; }
            }
            if (text == null && ev.getText() != null && !ev.getText().isEmpty()) text = ev.getText().get(0);
            if (text == null) return null;
            if (s > e) { int t = s; s = e; e = t; }
            if (s < 0 || e > text.length() || s == e) return null;
            String sel = text.subSequence(s, e).toString().trim();
            sel = sel.replaceAll("^[^A-Za-z]+|[^A-Za-z]+$", ""); // strip punctuation around
            if (sel.isEmpty() || sel.length() > 60) return null;
            if (!sel.matches(".*[A-Za-z].*")) return null;
            if (sel.split("\\s+").length > 6) return null;
            return sel;
        } catch (Exception ex) {
            return null;
        }
    }

    // ---------------------------------------------------------------- popup

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private void ensurePopup() {
        if (popup != null) return;
        popup = new LinearLayout(this);
        popup.setOrientation(LinearLayout.VERTICAL);
        popup.setPadding(dp(18), dp(14), dp(18), dp(16));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), Color.parseColor("#CBD5E0"));
        popup.setBackground(bg);
        popup.setElevation(dp(10));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        tvWord = new TextView(this);
        tvWord.setTextSize(22);
        tvWord.setTextColor(Color.parseColor("#2B6CB0"));
        tvWord.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        row.addView(tvWord, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        ImageButton mic = new ImageButton(this);
        mic.setImageResource(R.drawable.ic_mic);
        mic.setBackgroundColor(Color.TRANSPARENT);
        mic.setContentDescription("Pronounce");
        mic.setOnClickListener(v -> speak(currentWord));
        row.addView(mic, new LinearLayout.LayoutParams(dp(44), dp(44)));

        ImageButton close = new ImageButton(this);
        close.setImageResource(R.drawable.ic_close);
        close.setBackgroundColor(Color.TRANSPARENT);
        close.setContentDescription("Close");
        close.setOnClickListener(v -> hidePopup());
        row.addView(close, new LinearLayout.LayoutParams(dp(44), dp(44)));

        popup.addView(row);

        tvPron = new TextView(this);
        tvPron.setTextSize(16);
        tvPron.setTextColor(Color.parseColor("#718096"));
        popup.addView(tvPron);

        tvMean = new TextView(this);
        tvMean.setTextSize(19);
        tvMean.setTextColor(Color.parseColor("#2D3748"));
        tvMean.setPadding(0, dp(6), 0, 0);
        popup.addView(tvMean);

        // tap anywhere outside the box -> close
        popup.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_OUTSIDE) { hidePopup(); return true; }
            return false;
        });
    }

    private void showFor(String text) {
        ensurePopup();
        currentWord = text;
        final int my = ++token;
        boolean single = !text.contains(" ");

        tvWord.setText(text);
        String[] v = Dict.vocab(text);
        String pron = single ? Dict.pron(text) : (v != null ? v[0] : "");
        tvPron.setText(pron.isEmpty() ? "" : "উচ্চারণ: " + pron);
        tvPron.setVisibility(pron.isEmpty() ? android.view.View.GONE : android.view.View.VISIBLE);

        String key = text.toLowerCase(Locale.ROOT);
        String cached = v != null ? v[1] : meaningCache.get(key);
        tvMean.setText(cached != null ? cached : "অর্থ খুঁজছি…");

        if (popup.getParent() == null) {
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    getResources().getDisplayMetrics().widthPixels - dp(24),
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
            lp.y = dp(28);
            try { wm.addView(popup, lp); } catch (Exception ignored) { return; }
        }

        speak(text);

        if (cached == null) {
            final String q = text;
            net.execute(() -> {
                String m = fetchMeaning(q);
                ui.post(() -> {
                    if (my != token || popup == null) return;
                    if (m != null) { meaningCache.put(key, m); tvMean.setText(m); }
                    else tvMean.setText("অর্থ পাওয়া যায়নি (ইন্টারনেট চেক করুন)");
                });
            });
        }
    }

    private void hidePopup() {
        token++;
        if (pending != null) { ui.removeCallbacks(pending); pending = null; }
        if (popup != null && popup.getParent() != null) {
            try { wm.removeView(popup); } catch (Exception ignored) { }
        }
        if (tts != null) tts.stop();
    }

    private void speak(String text) {
        if (tts == null || !ttsReady || text == null || text.isEmpty()) return;
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "wh");
    }

    // ---------------------------------------------------------------- meaning

    private String fetchMeaning(String q) {
        String m = googleMeaning(q);
        if (m == null || m.equalsIgnoreCase(q)) m = myMemory(q);
        if (m != null && m.equalsIgnoreCase(q)) m = null;
        return m;
    }

    private String httpGet(String u) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setConnectTimeout(6000);
        c.setReadTimeout(8000);
        c.setRequestProperty("User-Agent", "Mozilla/5.0");
        try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            return sb.toString();
        } finally {
            c.disconnect();
        }
    }

    private String googleMeaning(String q) {
        try {
            String u = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=bn&dt=t&dt=bd&q="
                    + URLEncoder.encode(q, "UTF-8");
            JSONArray root = new JSONArray(httpGet(u));
            JSONArray seg = root.getJSONArray(0);
            StringBuilder main = new StringBuilder();
            for (int i = 0; i < seg.length(); i++) {
                JSONArray part = seg.optJSONArray(i);
                if (part != null && !part.isNull(0)) main.append(part.getString(0));
            }
            String result = main.toString().trim();
            if (result.isEmpty()) return null;
            // extra meanings for single words (dictionary section)
            if (!q.contains(" ") && root.length() > 1 && !root.isNull(1)) {
                JSONArray dict = root.optJSONArray(1);
                if (dict != null && dict.length() > 0) {
                    JSONArray first = dict.optJSONArray(0);
                    JSONArray terms = first != null ? first.optJSONArray(1) : null;
                    if (terms != null) {
                        StringBuilder sb = new StringBuilder(result);
                        int added = 0;
                        for (int i = 0; i < terms.length() && added < 3; i++) {
                            String t = terms.optString(i, "").trim();
                            if (!t.isEmpty() && !result.contains(t)) { sb.append(", ").append(t); added++; }
                        }
                        result = sb.toString();
                    }
                }
            }
            return result;
        } catch (Exception e) {
            return null;
        }
    }

    private String myMemory(String q) {
        try {
            String u = "https://api.mymemory.translated.net/get?langpair=en|bn&q=" + URLEncoder.encode(q, "UTF-8");
            org.json.JSONObject o = new org.json.JSONObject(httpGet(u));
            String t = o.getJSONObject("responseData").optString("translatedText", "").trim();
            return t.isEmpty() ? null : t;
        } catch (Exception e) {
            return null;
        }
    }
}
