package com.bnword.helper;

import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;
import android.widget.Toast;

public class ToggleTileService extends TileService {

    static final String PREFS = "wh_prefs";
    static final String KEY_ON = "enabled";

    static boolean isOn(Context c) {
        return c.getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY_ON, false);
    }

    static void setOn(Context c, boolean on) {
        SharedPreferences sp = c.getSharedPreferences(PREFS, MODE_PRIVATE);
        sp.edit().putBoolean(KEY_ON, on).apply();
    }

    static void refresh(Context c) {
        try {
            TileService.requestListeningState(c, new ComponentName(c, ToggleTileService.class));
        } catch (Exception ignored) { }
    }

    @Override public void onStartListening() { updateTile(); }

    @Override public void onClick() {
        if (!WordAccessibilityService.connected) {
            // Accessibility permission not given yet -> open the app so the user can enable it
            Intent i = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            Toast.makeText(this, "আগে অ্যাপ খুলে Accessibility চালু করুন", Toast.LENGTH_LONG).show();
            if (Build.VERSION.SDK_INT >= 34) {
                PendingIntent pi = PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE);
                startActivityAndCollapse(pi);
            } else {
                startActivityAndCollapse(i);
            }
            return;
        }
        boolean on = !isOn(this);
        setOn(this, on);
        if (!on) WordAccessibilityService.dismissIfShowing();
        updateTile();
    }

    private void updateTile() {
        Tile t = getQsTile();
        if (t == null) return;
        boolean on = isOn(this) && WordAccessibilityService.connected;
        t.setState(on ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        t.setLabel("Word Helper");
        if (Build.VERSION.SDK_INT >= 29) t.setSubtitle(on ? "চালু" : "বন্ধ");
        t.updateTile();
    }
}
