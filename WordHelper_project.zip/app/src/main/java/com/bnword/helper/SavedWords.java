package com.bnword.helper;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Stores every looked-up word on the phone (newest first). */
public class SavedWords {

    public static class Item {
        public String word, pron, meaning;
        public long time;
    }

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("saved_words", Context.MODE_PRIVATE);
    }

    public static String dayKey(long t) {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date(t));
    }

    public static synchronized List<Item> list(Context c) {
        List<Item> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp(c).getString("items", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Item it = new Item();
                it.word = o.optString("w");
                it.pron = o.optString("p");
                it.meaning = o.optString("m");
                it.time = o.optLong("t");
                out.add(it);
            }
        } catch (Exception ignored) { }
        return out;
    }

    private static void write(Context c, List<Item> items) {
        JSONArray a = new JSONArray();
        try {
            for (Item it : items) {
                JSONObject o = new JSONObject();
                o.put("w", it.word);
                o.put("p", it.pron);
                o.put("m", it.meaning);
                o.put("t", it.time);
                a.put(o);
            }
        } catch (Exception ignored) { }
        sp(c).edit().putString("items", a.toString()).apply();
    }

    /** Adds the word, or refreshes it (moves to top) if it already exists. */
    public static synchronized void add(Context c, String word, String pron, String meaning) {
        if (word == null || word.trim().isEmpty() || meaning == null || meaning.isEmpty()) return;
        List<Item> items = list(c);
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).word.equalsIgnoreCase(word)) { items.remove(i); break; }
        }
        Item it = new Item();
        it.word = word.trim();
        it.pron = pron == null ? "" : pron;
        it.meaning = meaning;
        it.time = System.currentTimeMillis();
        items.add(0, it);
        write(c, items);
    }

    public static synchronized void remove(Context c, String word) {
        List<Item> items = list(c);
        for (int i = items.size() - 1; i >= 0; i--) {
            if (items.get(i).word.equalsIgnoreCase(word)) items.remove(i);
        }
        write(c, items);
    }

    public static synchronized void removeDay(Context c, String dayKey) {
        List<Item> items = list(c);
        for (int i = items.size() - 1; i >= 0; i--) {
            if (dayKey(items.get(i).time).equals(dayKey)) items.remove(i);
        }
        write(c, items);
    }

    public static synchronized void clear(Context c) {
        sp(c).edit().remove("items").apply();
    }
}
