package com.bnword.helper;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

public class ProcessTextActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        CharSequence t = getIntent().getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT);
        if (!WordAccessibilityService.connected) {
            Toast.makeText(this, "আগে Accessibility চালু করুন", Toast.LENGTH_LONG).show();
        } else if (!ToggleTileService.isOn(this)) {
            Toast.makeText(this, "Word Helper বন্ধ আছে (টাইল চালু করুন)", Toast.LENGTH_LONG).show();
        } else if (t != null) {
            WordAccessibilityService.showExternal(t.toString());
        }
        finish();
        overridePendingTransition(0, 0);
    }
}
