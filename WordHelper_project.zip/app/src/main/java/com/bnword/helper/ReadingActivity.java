package com.bnword.helper;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Hosts the Reading Creator tool inside Word Helper. */
public class ReadingActivity extends Activity {
    private WebView web;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService net = Executors.newSingleThreadExecutor();
    private int lookupToken = 0;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.parseColor("#0284C7"));
        Dict.load(this);

        tts = new TextToSpeech(this, st -> {
            if (st == TextToSpeech.SUCCESS) ttsReady = VoiceUtil.apply(tts);
        });

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onJsAlert(WebView v, String url, String msg, JsResult r) {
                new AlertDialog.Builder(ReadingActivity.this).setMessage(msg)
                        .setPositiveButton("ঠিক আছে", (d, w) -> r.confirm())
                        .setOnCancelListener(d -> r.confirm()).show();
                return true;
            }
            @Override public boolean onJsConfirm(WebView v, String url, String msg, JsResult r) {
                new AlertDialog.Builder(ReadingActivity.this).setMessage(msg)
                        .setPositiveButton("হ্যাঁ", (d, w) -> r.confirm())
                        .setNegativeButton("না", (d, w) -> r.cancel())
                        .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/reading_creator.html");
    }

    private class Bridge {
        @JavascriptInterface public void speak(String text) {
            ui.post(() -> {
                if (tts != null && ttsReady) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "rc");
            });
        }
        @JavascriptInterface public void stop() {
            ui.post(() -> { if (tts != null) tts.stop(); });
        }

        /**
         * Instant local lookup (offline vocab + pronunciation). Returns JSON string:
         * {"pron":"...","meaning":"..."} — meaning may be empty if not in offline list.
         */
        @JavascriptInterface public String localLookup(String word) {
            if (word == null) return "{}";
            String w = word.trim();
            if (w.isEmpty()) return "{}";
            try {
                JSONObject o = new JSONObject();
                String[] v = Dict.vocab(w);
                String pron;
                if (!w.contains(" ")) {
                    pron = Dict.pron(w);
                } else if (v != null) {
                    pron = v[0];
                } else {
                    StringBuilder pb = new StringBuilder();
                    for (String part : w.split("\\s+")) {
                        String x = Dict.pron(part);
                        if (!x.isEmpty()) pb.append(x).append(' ');
                    }
                    pron = pb.toString().trim();
                }
                o.put("pron", pron == null ? "" : pron);
                String mean = (v != null && v[1] != null) ? v[1] : "";
                o.put("meaning", mean);
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        /**
         * Full lookup like the main app: offline first, then Google Translate (+ dict senses),
         * then MyMemory. Result delivered via window.onAndroidLookup(word, pron, meaning).
         * Auto-saves to homepage SavedWords when a meaning is found.
         */
        @JavascriptInterface public void lookupWord(String word) {
            if (word == null) return;
            final String q = word.trim();
            if (q.isEmpty()) return;
            final int my = ++lookupToken;

            net.execute(() -> {
                String pron = "";
                String mean = null;
                try {
                    String[] v = Dict.vocab(q);
                    if (!q.contains(" ")) pron = Dict.pron(q);
                    else if (v != null) pron = v[0] != null ? v[0] : "";
                    else {
                        StringBuilder pb = new StringBuilder();
                        for (String part : q.split("\\s+")) {
                            String x = Dict.pron(part);
                            if (!x.isEmpty()) pb.append(x).append(' ');
                        }
                        pron = pb.toString().trim();
                    }
                    if (v != null && v[1] != null && !v[1].isEmpty()) mean = v[1];
                    if (mean == null) mean = googleMeaning(q);
                    if (mean == null || mean.equalsIgnoreCase(q)) mean = myMemory(q);
                    if (mean != null && mean.equalsIgnoreCase(q)) mean = null;
                } catch (Exception ignored) { }

                final String fPron = pron == null ? "" : pron;
                final String fMean = mean;
                ui.post(() -> {
                    if (my != lookupToken) return;
                    if (fMean != null && !fMean.isEmpty()) {
                        SavedWords.add(ReadingActivity.this, q, fPron, fMean);
                    }
                    deliverLookup(q, fPron, fMean);
                });
            });
        }
    }

    private void deliverLookup(String word, String pron, String meaning) {
        try {
            String w = JSONObject.quote(word == null ? "" : word);
            String p = JSONObject.quote(pron == null ? "" : pron);
            String m = JSONObject.quote(meaning == null ? "" : meaning);
            web.evaluateJavascript(
                    "(function(){if(typeof onAndroidLookup==='function')onAndroidLookup(" + w + "," + p + "," + m + ");})()",
                    null);
        } catch (Exception ignored) { }
    }

    private String httpGet(String u) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setConnectTimeout(6000);
        c.setReadTimeout(8000);
        c.setRequestProperty("User-Agent", "Mozilla/5.0");
        try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            return sb.toString();
        } finally {
            c.disconnect();
        }
    }

    private String googleMeaning(String q) {
        try {
            String u = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=bn&dt=t&dt=bd&q="
                    + URLEncoder.encode(q, "UTF-8");
            JSONArray root = new JSONArray(httpGet(u));
            JSONArray seg = root.getJSONArray(0);
            StringBuilder main = new StringBuilder();
            for (int i = 0; i < seg.length(); i++) {
                JSONArray part = seg.optJSONArray(i);
                if (part != null && !part.isNull(0)) main.append(part.getString(0));
            }
            String result = main.toString().trim();
            if (result.isEmpty()) return null;
            if (!q.contains(" ") && root.length() > 1 && !root.isNull(1)) {
                JSONArray dict = root.optJSONArray(1);
                if (dict != null && dict.length() > 0) {
                    JSONArray first = dict.optJSONArray(0);
                    JSONArray terms = first != null ? first.optJSONArray(1) : null;
                    if (terms != null) {
                        StringBuilder sb = new StringBuilder(result);
                        int added = 0;
                        for (int i = 0; i < terms.length() && added < 3; i++) {
                            String t = terms.optString(i, "").trim();
                            if (!t.isEmpty() && !result.contains(t)) {
                                sb.append(", ").append(t);
                                added++;
                            }
                        }
                        result = sb.toString();
                    }
                }
            }
            return result;
        } catch (Exception e) {
            return null;
        }
    }

    private String myMemory(String q) {
        try {
            String u = "https://api.mymemory.translated.net/get?langpair=en|bn&q="
                    + URLEncoder.encode(q, "UTF-8");
            JSONObject o = new JSONObject(httpGet(u));
            String t = o.getJSONObject("responseData").optString("translatedText", "").trim();
            if (t.isEmpty() || t.contains("MYMEMORY WARNING") || t.contains("QUERY LENGTH LIMIT")) return null;
            return t;
        } catch (Exception e) {
            return null;
        }
    }

    @Override public void onBackPressed() {
        web.evaluateJavascript(
                "(function(){var r=document.getElementById('reader');" +
                "if(r&&r.classList.contains('active')){showHome();return 'h';}return 'x';})()",
                v -> { if (v != null && v.contains("h")) return; finish(); });
    }

    @Override protected void onDestroy() {
        lookupToken++;
        net.shutdownNow();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
