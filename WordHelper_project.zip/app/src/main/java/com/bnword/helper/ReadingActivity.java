package com.bnword.helper;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

/** Hosts the Reading Creator tool inside Word Helper. */
public class ReadingActivity extends Activity {
    private WebView web;
    private TextToSpeech tts;
    private boolean ttsReady = false;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.parseColor("#0284C7"));

        tts = new TextToSpeech(this, st -> {
            if (st == TextToSpeech.SUCCESS) ttsReady = VoiceUtil.apply(tts);
        });

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // keeps saved readings (localStorage)
        s.setAllowFileAccess(true);
        s.setAllowUniversalAccessFromFileURLs(true); // lets the page call the translate API
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onJsAlert(WebView v, String url, String msg, JsResult r) {
                new AlertDialog.Builder(ReadingActivity.this).setMessage(msg)
                        .setPositiveButton("ঠিক আছে", (d, w) -> r.confirm())
                        .setOnCancelListener(d -> r.confirm()).show();
                return true;
            }
            @Override public boolean onJsConfirm(WebView v, String url, String msg, JsResult r) {
                new AlertDialog.Builder(ReadingActivity.this).setMessage(msg)
                        .setPositiveButton("হ্যাঁ", (d, w) -> r.confirm())
                        .setNegativeButton("না", (d, w) -> r.cancel())
                        .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/reading_creator.html");
    }

    private class Bridge {
        @JavascriptInterface public void speak(String text) {
            runOnUiThread(() -> {
                if (tts != null && ttsReady) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "rc");
                else Toast.makeText(ReadingActivity.this, "ভয়েস প্রস্তুত নয়", Toast.LENGTH_SHORT).show();
            });
        }
        @JavascriptInterface public void stop() {
            runOnUiThread(() -> { if (tts != null) tts.stop(); });
        }
        /** Called from Reading Creator when user taps 💾 সেভ on a selected word. */
        @JavascriptInterface public void saveWord(String word, String pron, String meaning) {
            if (word == null || word.trim().isEmpty()) return;
            String m = meaning == null ? "" : meaning.trim();
            if (m.isEmpty() || m.equals("অর্থ পাওয়া যায়নি") || m.equals("ইন্টারনেট লাগবে")) {
                runOnUiThread(() -> Toast.makeText(ReadingActivity.this,
                        "অর্থ পাওয়া যায়নি — সেভ হয়নি", Toast.LENGTH_SHORT).show());
                return;
            }
            SavedWords.add(ReadingActivity.this, word.trim(),
                    pron == null ? "" : pron.trim(), m);
            runOnUiThread(() -> Toast.makeText(ReadingActivity.this,
                    "✓ \"" + word.trim() + "\" সেভ হয়েছে", Toast.LENGTH_SHORT).show());
        }
    }

    @Override public void onBackPressed() {
        // inside a reading -> go back to the Reading Creator list first
        web.evaluateJavascript(
                "(function(){var r=document.getElementById('reader');" +
                "if(r&&r.classList.contains('active')){showHome();return 'h';}return 'x';})()",
                v -> { if (v != null && v.contains("h")) return; finish(); });
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
