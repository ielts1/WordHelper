package com.bnword.helper;

import android.content.Context;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

/** Offline Bengali pronunciation + built-in vocabulary (ported from the HTML file). */
final class Dict {
    private static final Map<String, String> PRON = new HashMap<>();
    private static final Map<String, String[]> VOCAB = new HashMap<>(); // word -> {pron, mean}
    private static boolean loaded = false;

    static synchronized void load(Context c) {
        if (loaded) return;
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(c.getAssets().open("pron.tsv"), "UTF-8"));
            String line;
            while ((line = r.readLine()) != null) {
                String[] p = line.split("\t");
                if (p.length >= 2) PRON.put(p[0], p[1]);
            }
            r.close();
            r = new BufferedReader(new InputStreamReader(c.getAssets().open("vocab.tsv"), "UTF-8"));
            while ((line = r.readLine()) != null) {
                String[] p = line.split("\t");
                if (p.length >= 3) VOCAB.put(p[0], new String[]{p[1], p[2]});
            }
            r.close();
        } catch (Exception ignored) { }
        loaded = true;
    }

    /** true if this exact word is in the hand-checked lists (these are better than computed spellings). */
    static boolean curated(String word) {
        if (word == null) return false;
        String w = word.toLowerCase().trim().replaceAll("[^a-z']", "");
        String[] v = VOCAB.get(w);
        return PRON.containsKey(w) || (v != null && v[0] != null && !v[0].isEmpty());
    }

    static String[] vocab(String phrase) {
        return VOCAB.get(phrase.toLowerCase().trim());
    }

    private static String fixIng(String stem, String suffix) {
        if (!suffix.equals("\u09BF\u0982") || stem.isEmpty()) return suffix;
        char last = stem.charAt(stem.length() - 1);
        if (last == '\u0987') return "\u0982";
        boolean vowelSign = (last >= '\u09BE' && last <= '\u09CC');
        return vowelSign ? "\u0987\u0982" : suffix;
    }

    private static String[] splitSuffix(String w) {
        String suffix = "";
        String base = w;
        if (w.endsWith("tion") && w.length() > 5) { suffix = "শন"; base = w.substring(0, w.length() - 4); }
        else if (w.endsWith("sion") && w.length() > 5) { suffix = "ঝন"; base = w.substring(0, w.length() - 4); }
        else if (w.endsWith("ness") && w.length() > 5) { suffix = "নেস"; base = w.substring(0, w.length() - 4); }
        else if (w.endsWith("ment") && w.length() > 5) { suffix = "মেন্ট"; base = w.substring(0, w.length() - 4); }
        else if (w.endsWith("ing") && w.length() > 4) { suffix = "িং"; base = w.substring(0, w.length() - 3); }
        else if (w.endsWith("ly") && w.length() > 4) { suffix = "লি"; base = w.substring(0, w.length() - 2); }
        else if (w.endsWith("ed") && w.length() > 4) {
            if (w.endsWith("ied")) { suffix = "াইড"; base = w.substring(0, w.length() - 3); }
            else { suffix = "ড"; base = w.substring(0, w.length() - 2); }
        }
        else if (w.endsWith("es") && w.length() > 3) { suffix = "স"; base = w.substring(0, w.length() - 2); }
        else if (w.endsWith("s") && w.length() > 3 && !w.endsWith("ss")) { suffix = "স"; base = w.substring(0, w.length() - 1); }
        return new String[]{base, suffix};
    }

    /** Hand-checked pronunciation (from the HTML file / vocabulary), or null when we only could guess. */
    static String pronCurated(String word) {
        if (word == null) return null;
        String w = word.toLowerCase().trim().replaceAll("[^a-z']", "");
        if (w.isEmpty()) return null;
        String[] v = VOCAB.get(w);
        if (v != null && v[0] != null && !v[0].isEmpty()) return v[0];
        String d = PRON.get(w);
        if (d != null) return d;
        String[] sp = splitSuffix(w);
        d = PRON.get(sp[0]);
        if (d != null && !sp[1].isEmpty()) return d + fixIng(d, sp[1]);
        return null;
    }

    static String local(String word) { return pronCurated(word); }

    /** Spelling-based rough guess (only used until the online pronunciation arrives). */
    static String guess(String word) {
        if (word == null) return "";
        String w = word.toLowerCase().trim().replaceAll("[^a-z']", "");
        if (w.isEmpty()) return "";
        String[] sp = splitSuffix(w);
        String s = sp[0];
        for (String[] rule : PronRules.RULES) s = s.replaceAll(rule[0], rule[1]);
        s = s.replaceAll("[^\\u0985-\\u09B9\\u0981-\\u0983\\u09BE-\\u09CC\\u09CD\\u09DC-\\u09DF]", "");
        String out = s + fixIng(s, sp[1]);
        return out.isEmpty() ? w : out;
    }

    static String pron(String word) {
        String c = pronCurated(word);
        return c != null ? c : guess(word);
    }
}
