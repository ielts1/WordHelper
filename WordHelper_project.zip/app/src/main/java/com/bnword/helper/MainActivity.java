package com.bnword.helper;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.VideoView;
import android.net.Uri;

import java.util.List;

public class MainActivity extends Activity {
    private static final int BLUE = Color.parseColor("#2B6CB0");
    private static final int BG = Color.parseColor("#EEF2F7");

    private TextView statusPill;
    private TextView accBtn;
    private Switch sw;
    private boolean binding = false;
    private LinearLayout listBox;
    private TextView countTv;
    private VideoView video;
    private LinearLayout videoCard;
    private TextToSpeech tts;
    private boolean ttsReady = false;

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(16));
        c.setBackground(rounded(Color.WHITE, 20));
        c.setElevation(dp(3));
        return c;
    }

    private LinearLayout.LayoutParams cardLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(16), dp(14), dp(16), 0);
        return lp;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView pillButton(String s, int bgColor, int textColor) {
        TextView t = text(s, 14, textColor, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(16), dp(11), dp(16), dp(11));
        t.setBackground(rounded(bgColor, 14));
        return t;
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BLUE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        // ---------------- header
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(22), dp(22), dp(22), dp(26));
        GradientDrawable hg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.parseColor("#2B6CB0"), Color.parseColor("#6B46C1")});
        float r = dp(28);
        hg.setCornerRadii(new float[]{0, 0, 0, 0, r, r, r, r});
        header.setBackground(hg);

        header.addView(text("Word Helper", 30, Color.WHITE, true));
        TextView sub = text("যেকোনো ইংরেজি শব্দ সিলেক্ট করুন — উচ্চারণ, বাংলা উচ্চারণ ও অর্থ জানুন", 14, Color.parseColor("#E9D8FD"), false);
        sub.setPadding(0, dp(4), 0, dp(14));
        header.addView(sub);

        statusPill = text("", 13, BLUE, true);
        statusPill.setPadding(dp(14), dp(7), dp(14), dp(7));
        header.addView(statusPill, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        root.addView(header);

        // ---------------- control card
        LinearLayout ctl = card();
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(text("শব্দ সহায়ক", 18, Color.parseColor("#1A202C"), true));
        col.addView(text("চালু থাকলে শব্দ সিলেক্ট করলেই অর্থ দেখাবে", 13, Color.parseColor("#718096"), false));
        row.addView(col, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        sw = new Switch(this);
        sw.setOnCheckedChangeListener((v, on) -> {
            if (binding) return;
            ToggleTileService.setOn(this, on);
            ToggleTileService.refresh(this);
            if (!on) WordAccessibilityService.dismissIfShowing();
        });
        row.addView(sw);
        ctl.addView(row);

        accBtn = pillButton("⚙  Accessibility সেটিংস খুলুন", Color.parseColor("#EBF4FF"), BLUE);
        accBtn.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        blp.topMargin = dp(14);
        ctl.addView(accBtn, blp);
        root.addView(ctl, cardLp());

        // ---------------- setup video card
        LinearLayout tut = card();
        tut.addView(text("▶  সেটআপ ভিডিও (পারমিশন দেওয়ার নিয়ম)", 17, Color.parseColor("#1A202C"), true));
        TextView hint = text("ভিডিওতে চাপলে থামবে / আবার চলবে", 12, Color.parseColor("#718096"), false);
        hint.setPadding(0, dp(2), 0, dp(8));
        tut.addView(hint);
        video = new VideoView(this);
        LinearLayout.LayoutParams vlp = new LinearLayout.LayoutParams(dp(270), dp(480));
        vlp.gravity = Gravity.CENTER_HORIZONTAL;
        tut.addView(video, vlp);
        video.setVideoURI(Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.setup_guide));
        video.setOnPreparedListener(mp -> { mp.setLooping(true); mp.setVolume(0f, 0f); video.start(); });
        video.setOnClickListener(v -> { if (video.isPlaying()) video.pause(); else video.start(); });
        videoCard = tut;
        root.addView(tut, cardLp());

        // ---------------- saved words card
        LinearLayout saved = card();
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(text("📚  সেভ করা শব্দ", 18, Color.parseColor("#1A202C"), true),
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        countTv = text("", 13, Color.parseColor("#718096"), false);
        head.addView(countTv);
        saved.addView(head);
        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        saved.addView(listBox);
        LinearLayout.LayoutParams slp = cardLp();
        slp.bottomMargin = dp(24);
        root.addView(saved, slp);

        tts = new TextToSpeech(this, st -> {
            if (st == TextToSpeech.SUCCESS) ttsReady = VoiceUtil.apply(tts);
        });

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.addView(root);
        setContentView(sv);
    }

    @Override protected void onResume() {
        super.onResume();
        boolean conn = WordAccessibilityService.connected;
        statusPill.setText(conn ? "✅  Accessibility চালু আছে" : "⚠️  Accessibility এখনও চালু হয়নি");
        statusPill.setTextColor(Color.parseColor(conn ? "#276749" : "#C05621"));
        statusPill.setBackground(rounded(Color.parseColor(conn ? "#C6F6D5" : "#FEEBC8"), 20));
        accBtn.setVisibility(conn ? View.GONE : View.VISIBLE);
        binding = true;
        sw.setChecked(ToggleTileService.isOn(this));
        binding = false;
        ToggleTileService.refresh(this);
        refreshList();
        // show the setup video only while Accessibility is not enabled
        if (conn) {
            videoCard.setVisibility(View.GONE);
            if (video != null) video.pause();
        } else {
            videoCard.setVisibility(View.VISIBLE);
            if (video != null) video.start();
        }
    }

    @Override protected void onPause() {
        super.onPause();
        if (video != null && video.isPlaying()) video.pause();
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    private void confirm(String msg, Runnable ok) {
        new AlertDialog.Builder(this)
                .setMessage(msg)
                .setPositiveButton("মুছুন", (d, w) -> { ok.run(); refreshList(); })
                .setNegativeButton("না", null)
                .show();
    }

    private void speak(String word) {
        if (tts != null && ttsReady) tts.speak(word, TextToSpeech.QUEUE_FLUSH, null, "ml");
    }

    private void refreshList() {
        listBox.removeAllViews();
        List<SavedWords.Item> items = SavedWords.list(this);
        if (items.isEmpty()) {
            countTv.setText("");
            TextView e = text("এখনও কোনো শব্দ সেভ হয়নি।\nশব্দ সিলেক্ট করলে এখানে নিজে নিজে জমা হবে।", 14, Color.parseColor("#A0AEC0"), false);
            e.setGravity(Gravity.CENTER);
            e.setPadding(0, dp(18), 0, dp(10));
            listBox.addView(e);
            return;
        }
        countTv.setText("মোট " + items.size() + "টি");

        String today = SavedWords.dayKey(System.currentTimeMillis());
        String lastDay = "";
        for (SavedWords.Item it : items) {
            final String day = SavedWords.dayKey(it.time);
            if (!day.equals(lastDay)) {
                lastDay = day;
                LinearLayout h = new LinearLayout(this);
                h.setOrientation(LinearLayout.HORIZONTAL);
                h.setGravity(Gravity.CENTER_VERTICAL);
                h.setPadding(0, dp(14), 0, dp(2));
                h.addView(text(day.equals(today) ? "আজ  •  " + day : day, 14, Color.parseColor("#4A5568"), true),
                        new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
                TextView dd = text("এই দিনের সব মুছুন", 12, Color.parseColor("#C53030"), true);
                dd.setPadding(dp(10), dp(6), dp(10), dp(6));
                dd.setBackground(rounded(Color.parseColor("#FFF5F5"), 12));
                dd.setOnClickListener(v -> confirm(day + " তারিখের সব শব্দ মুছে ফেলবেন?", () -> SavedWords.removeDay(this, day)));
                h.addView(dd);
                listBox.addView(h);
            }

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(14), dp(8), dp(4), dp(8));
            row.setBackground(rounded(Color.parseColor("#F7FAFC"), 14));
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            rlp.topMargin = dp(6);

            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.addView(text(it.word, 18, BLUE, true));
            if (!it.pron.isEmpty()) col.addView(text("উচ্চারণ: " + it.pron, 13, Color.parseColor("#718096"), false));
            col.addView(text(it.meaning, 16, Color.parseColor("#2D3748"), false));
            row.addView(col, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

            final String word = it.word;
            col.setOnClickListener(v -> speak(word));

            ImageButton mic = new ImageButton(this);
            mic.setImageResource(R.drawable.ic_mic);
            mic.setBackgroundColor(Color.TRANSPARENT);
            mic.setContentDescription("Pronounce");
            mic.setOnClickListener(v -> speak(word));
            row.addView(mic, new LinearLayout.LayoutParams(dp(44), dp(44)));

            ImageButton del = new ImageButton(this);
            del.setImageResource(R.drawable.ic_close);
            del.setBackgroundColor(Color.TRANSPARENT);
            del.setContentDescription("Delete");
            del.setOnClickListener(v -> { SavedWords.remove(this, word); refreshList(); });
            row.addView(del, new LinearLayout.LayoutParams(dp(44), dp(44)));

            listBox.addView(row, rlp);
        }

        TextView all = pillButton("🗑  সব শব্দ মুছুন", Color.parseColor("#FFF5F5"), Color.parseColor("#C53030"));
        all.setOnClickListener(v -> confirm("সব সেভ করা শব্দ মুছে ফেলবেন?", () -> SavedWords.clear(this)));
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        alp.topMargin = dp(16);
        listBox.addView(all, alp);
    }
}
