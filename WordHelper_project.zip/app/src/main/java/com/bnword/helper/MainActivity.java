package com.bnword.helper;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView status;
    private Switch sw;
    private boolean binding = false;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad * 2, pad, pad);

        TextView title = new TextView(this);
        title.setText("Word Helper");
        title.setTextSize(26);
        title.setTextColor(Color.parseColor("#2B6CB0"));
        root.addView(title);

        status = new TextView(this);
        status.setTextSize(16);
        status.setPadding(0, pad, 0, pad);
        root.addView(status);

        Button open = new Button(this);
        open.setText("১) Accessibility সেটিংস খুলুন");
        open.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(open);

        sw = new Switch(this);
        sw.setText("২) শব্দ সহায়ক চালু / বন্ধ  ");
        sw.setTextSize(18);
        sw.setPadding(0, pad, 0, pad);
        sw.setOnCheckedChangeListener((v, on) -> {
            if (binding) return;
            ToggleTileService.setOn(this, on);
            ToggleTileService.refresh(this);
            if (!on) WordAccessibilityService.dismissIfShowing();
        });
        root.addView(sw);

        TextView help = new TextView(this);
        help.setTextSize(15);
        help.setLineSpacing(6, 1f);
        help.setText(
            "কীভাবে সেটআপ করবেন:\n\n"
            + "১. উপরের বাটনে চাপ দিয়ে Accessibility সেটিংসে যান → Installed apps / Downloaded apps থেকে “Word Helper” খুলে চালু (ON) করুন। (Restricted setting দেখালে: ফোন সেটিংস → Apps → Word Helper → ⋮ → Allow restricted settings, তারপর আবার চালু করুন।)\n\n"
            + "২. উপর থেকে নোটিফিকেশন প্যানেল নামিয়ে Quick Settings খুলুন → পেন্সিল (Edit) আইকন → “Word Helper” টাইলটি টেনে উপরের অংশে বসান।\n\n"
            + "৩. টাইলে এক ট্যাপে চালু, আবার এক ট্যাপে বন্ধ।\n\n"
            + "চালু থাকা অবস্থায় যেকোনো অ্যাপে ইংরেজি শব্দ লং-প্রেস করে সিলেক্ট করলে উচ্চারণ শোনা যাবে এবং বাংলা উচ্চারণ ও অর্থ দেখাবে। ✕ চাপলে বা বাইরে ট্যাপ করলে বক্স চলে যাবে।");
        root.addView(help);

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
    }

    @Override protected void onResume() {
        super.onResume();
        boolean conn = WordAccessibilityService.connected;
        status.setText(conn ? "✅ Accessibility চালু আছে" : "⚠️ Accessibility এখনও চালু হয়নি");
        status.setTextColor(Color.parseColor(conn ? "#2F855A" : "#C05621"));
        binding = true;
        sw.setChecked(ToggleTileService.isOn(this));
        binding = false;
        ToggleTileService.refresh(this);
    }
}
