package com.bnword.helper;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ImageButton;
import android.app.AlertDialog;
import android.speech.tts.TextToSpeech;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private TextView status;
    private Switch sw;
    private boolean binding = false;
    private LinearLayout listBox;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private int pad;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        pad = (int) (20 * getResources().getDisplayMetrics().density);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad * 2, pad, pad);

        TextView title = new TextView(this);
        title.setText("Word Helper");
        title.setTextSize(26);
        title.setTextColor(Color.parseColor("#2B6CB0"));
        root.addView(title);

        status = new TextView(this);
        status.setTextSize(16);
        status.setPadding(0, pad, 0, pad);
        root.addView(status);

        Button open = new Button(this);
        open.setText("১) Accessibility সেটিংস খুলুন");
        open.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(open);

        sw = new Switch(this);
        sw.setText("২) শব্দ সহায়ক চালু / বন্ধ  ");
        sw.setTextSize(18);
        sw.setPadding(0, pad, 0, pad);
        sw.setOnCheckedChangeListener((v, on) -> {
            if (binding) return;
            ToggleTileService.setOn(this, on);
            ToggleTileService.refresh(this);
            if (!on) WordAccessibilityService.dismissIfShowing();
        });
        root.addView(sw);

        TextView help = new TextView(this);
        help.setTextSize(15);
        help.setLineSpacing(6, 1f);
        help.setText(
            "কীভাবে সেটআপ করবেন:\n\n"
            + "১. উপরের বাটনে চাপ দিয়ে Accessibility সেটিংসে যান → Installed apps / Downloaded apps থেকে “Word Helper” খুলে চালু (ON) করুন। (Restricted setting দেখালে: ফোন সেটিংস → Apps → Word Helper → ⋮ → Allow restricted settings, তারপর আবার চালু করুন।)\n\n"
            + "২. উপর থেকে নোটিফিকেশন প্যানেল নামিয়ে Quick Settings খুলুন → পেন্সিল (Edit) আইকন → “Word Helper” টাইলটি টেনে উপরের অংশে বসান।\n\n"
            + "৩. টাইলে এক ট্যাপে চালু, আবার এক ট্যাপে বন্ধ।\n\n"
            + "চালু থাকা অবস্থায় যেকোনো অ্যাপে ইংরেজি শব্দ লং-প্রেস করে সিলেক্ট করলে উচ্চারণ শোনা যাবে এবং বাংলা উচ্চারণ ও অর্থ দেখাবে। ✕ চাপলে বা বাইরে ট্যাপ করলে বক্স চলে যাবে।");
        root.addView(help);

        TextView saved = new TextView(this);
        saved.setText("📚 সেভ করা শব্দ");
        saved.setTextSize(20);
        saved.setTextColor(Color.parseColor("#2B6CB0"));
        saved.setPadding(0, pad, 0, pad / 2);
        root.addView(saved);

        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(listBox);

        tts = new TextToSpeech(this, st -> {
            if (st == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(Locale.US);
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
                tts.setSpeechRate(0.85f);
            }
        });

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
    }

    @Override protected void onResume() {
        super.onResume();
        boolean conn = WordAccessibilityService.connected;
        status.setText(conn ? "✅ Accessibility চালু আছে" : "⚠️ Accessibility এখনও চালু হয়নি");
        status.setTextColor(Color.parseColor(conn ? "#2F855A" : "#C05621"));
        binding = true;
        sw.setChecked(ToggleTileService.isOn(this));
        binding = false;
        ToggleTileService.refresh(this);
        refreshList();
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    private void confirm(String msg, Runnable ok) {
        new AlertDialog.Builder(this)
                .setMessage(msg)
                .setPositiveButton("মুছুন", (d, w) -> { ok.run(); refreshList(); })
                .setNegativeButton("না", null)
                .show();
    }

    private void refreshList() {
        listBox.removeAllViews();
        List<SavedWords.Item> items = SavedWords.list(this);
        if (items.isEmpty()) {
            TextView e = new TextView(this);
            e.setText("এখনও কোনো শব্দ সেভ হয়নি। শব্দ সিলেক্ট করলে এখানে নিজে নিজে জমা হবে।");
            e.setTextSize(15);
            e.setTextColor(Color.GRAY);
            listBox.addView(e);
            return;
        }

        TextView count = new TextView(this);
        count.setText("মোট " + items.size() + "টি শব্দ");
        count.setTextColor(Color.GRAY);
        listBox.addView(count);

        Button all = new Button(this);
        all.setText("🗑 সব শব্দ মুছুন");
        all.setOnClickListener(v -> confirm("সব সেভ করা শব্দ মুছে ফেলবেন?", () -> SavedWords.clear(this)));
        listBox.addView(all);

        String today = SavedWords.dayKey(System.currentTimeMillis());
        String lastDay = "";
        for (SavedWords.Item it : items) {
            final String day = SavedWords.dayKey(it.time);
            if (!day.equals(lastDay)) {
                lastDay = day;
                LinearLayout h = new LinearLayout(this);
                h.setOrientation(LinearLayout.HORIZONTAL);
                h.setGravity(Gravity.CENTER_VERTICAL);
                h.setPadding(0, pad, 0, 0);
                TextView t = new TextView(this);
                t.setText(day.equals(today) ? "আজ (" + day + ")" : day);
                t.setTextSize(16);
                t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
                t.setTextColor(Color.parseColor("#4A5568"));
                h.addView(t, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
                Button dd = new Button(this);
                dd.setText("এই দিনের সব মুছুন");
                dd.setTextSize(12);
                dd.setOnClickListener(v -> confirm(day + " তারিখের সব শব্দ মুছে ফেলবেন?", () -> SavedWords.removeDay(this, day)));
                h.addView(dd);
                listBox.addView(h);
            }

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(pad / 2, pad / 3, 0, pad / 3);
            android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
            bg.setColor(Color.parseColor("#F7FAFC"));
            bg.setCornerRadius(pad / 2f);
            row.setBackground(bg);
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            rlp.topMargin = pad / 4;

            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            TextView w = new TextView(this);
            w.setText(it.word);
            w.setTextSize(18);
            w.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            w.setTextColor(Color.parseColor("#2B6CB0"));
            col.addView(w);
            if (!it.pron.isEmpty()) {
                TextView p = new TextView(this);
                p.setText("উচ্চারণ: " + it.pron);
                p.setTextSize(14);
                p.setTextColor(Color.parseColor("#718096"));
                col.addView(p);
            }
            TextView m = new TextView(this);
            m.setText(it.meaning);
            m.setTextSize(16);
            m.setTextColor(Color.parseColor("#2D3748"));
            col.addView(m);
            row.addView(col, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

            // tap a saved word -> hear pronunciation
            final String word = it.word;
            col.setOnClickListener(v -> {
                if (tts != null && ttsReady) tts.speak(word, TextToSpeech.QUEUE_FLUSH, null, "ml");
            });

            ImageButton mic = new ImageButton(this);
            mic.setImageResource(R.drawable.ic_mic);
            mic.setBackgroundColor(Color.TRANSPARENT);
            mic.setContentDescription("Pronounce");
            mic.setOnClickListener(v -> {
                if (tts != null && ttsReady) tts.speak(word, TextToSpeech.QUEUE_FLUSH, null, "ml");
            });
            row.addView(mic, new LinearLayout.LayoutParams(pad * 2, pad * 2));

            ImageButton del = new ImageButton(this);
            del.setImageResource(R.drawable.ic_close);
            del.setBackgroundColor(Color.TRANSPARENT);
            del.setContentDescription("Delete");
            del.setOnClickListener(v -> { SavedWords.remove(this, word); refreshList(); });
            row.addView(del, new LinearLayout.LayoutParams(pad * 2, pad * 2));

            listBox.addView(row, rlp);
        }
    }
}
