package com.bnword.helper;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int BLUE = Color.parseColor("#2B6CB0");
    private static final int BG = Color.parseColor("#EEF2F7");

    private TextView statusPill;
    private TextView accBtn;
    private Switch sw;
    private boolean binding = false;
    private LinearLayout listBox;
    private TextView countTv;
    private VideoView video;
    private LinearLayout videoCard;
    private TextToSpeech tts;
    private boolean ttsReady = false;

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(16));
        c.setBackground(rounded(Color.WHITE, 20));
        c.setElevation(dp(3));
        return c;
    }

    private LinearLayout.LayoutParams cardLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(16), dp(14), dp(16), 0);
        return lp;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView pillButton(String s, int bgColor, int textColor) {
        TextView t = text(s, 14, textColor, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(16), dp(11), dp(16), dp(11));
        t.setBackground(rounded(bgColor, 14));
        return t;
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BLUE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        // ---------------- header
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(22), dp(22), dp(22), dp(26));
        GradientDrawable hg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.parseColor("#2B6CB0"), Color.parseColor("#6B46C1")});
        float r = dp(28);
        hg.setCornerRadii(new float[]{0, 0, 0, 0, r, r, r, r});
        header.setBackground(hg);

        header.addView(text("Word Helper", 30, Color.WHITE, true));
        TextView sub = text("যেকোনো ইংরেজি শব্দ সিলেক্ট করুন — উচ্চারণ, বাংলা উচ্চারণ ও অর্থ জানুন", 14, Color.parseColor("#E9D8FD"), false);
        sub.setPadding(0, dp(4), 0, dp(14));
        header.addView(sub);

        statusPill = text("", 13, BLUE, true);
        statusPill.setPadding(dp(14), dp(7), dp(14), dp(7));
        header.addView(statusPill, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        root.addView(header);

        // ---------------- control card
        LinearLayout ctl = card();
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(text("শব্দ সহায়ক", 18, Color.parseColor("#1A202C"), true));
        col.addView(text("চালু থাকলে শব্দ সিলেক্ট করলেই অর্থ দেখাবে", 13, Color.parseColor("#718096"), false));
        row.addView(col, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        sw = new Switch(this);
        sw.setOnCheckedChangeListener((v, on) -> {
            if (binding) return;
            ToggleTileService.setOn(this, on);
            ToggleTileService.refresh(this);
            if (!on) WordAccessibilityService.dismissIfShowing();
        });
        row.addView(sw);
        ctl.addView(row);

        accBtn = pillButton("⚙  Accessibility সেটিংস খুলুন", Color.parseColor("#EBF4FF"), BLUE);
        accBtn.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        blp.topMargin = dp(14);
        ctl.addView(accBtn, blp);
        root.addView(ctl, cardLp());

        // ---------------- Reading Creator entry
        LinearLayout rc = card();
        rc.setBackground(rounded(Color.parseColor("#E6F6FF"), 20));
        LinearLayout rcRow = new LinearLayout(this);
        rcRow.setOrientation(LinearLayout.HORIZONTAL);
        rcRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView rcIcon = text("📖", 30, Color.BLACK, false);
        rcIcon.setPadding(0, 0, dp(12), 0);
        rcRow.addView(rcIcon);
        LinearLayout rcCol = new LinearLayout(this);
        rcCol.setOrientation(LinearLayout.VERTICAL);
        rcCol.addView(text("Reading Creator", 18, Color.parseColor("#075985"), true));
        rcCol.addView(text("ইংরেজি প্যাসেজ দিয়ে রিডিং বানান — শব্দে ট্যাপ করলে উচ্চারণ ও বাংলা অর্থ, সঙ্গে পুরো বাংলা অনুবাদ", 13, Color.parseColor("#4A5568"), false));
        rcRow.addView(rcCol, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        rcRow.addView(text("›", 28, Color.parseColor("#0284C7"), true));
        rc.addView(rcRow);
        rc.setOnClickListener(v -> startActivity(new Intent(this, ReadingActivity.class)));
        root.addView(rc, cardLp());

        // ---------------- setup video card
        LinearLayout tut = card();
        tut.addView(text("▶  সেটআপ ভিডিও (পারমিশন দেওয়ার নিয়ম)", 17, Color.parseColor("#1A202C"), true));
        TextView hint = text("ভিডিওতে চাপলে থামবে / আবার চলবে", 12, Color.parseColor("#718096"), false);
        hint.setPadding(0, dp(2), 0, dp(8));
        tut.addView(hint);
        video = new VideoView(this);
        LinearLayout.LayoutParams vlp = new LinearLayout.LayoutParams(dp(270), dp(480));
        vlp.gravity = Gravity.CENTER_HORIZONTAL;
        tut.addView(video, vlp);
        video.setVideoURI(Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.setup_guide));
        video.setOnPreparedListener(mp -> { mp.setLooping(true); mp.setVolume(0f, 0f); video.start(); });
        video.setOnClickListener(v -> { if (video.isPlaying()) video.pause(); else video.start(); });
        videoCard = tut;
        root.addView(tut, cardLp());

        // ---------------- saved words card
        LinearLayout saved = card();
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(text("📚  সেভ করা শব্দ", 18, Color.parseColor("#1A202C"), true),
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        countTv = text("", 13, Color.parseColor("#718096"), false);
        head.addView(countTv);
        saved.addView(head);

        // PDF download button
        TextView pdfBtn = pillButton("📄  সব শব্দ PDF ডাউনলোড", Color.parseColor("#EBF8FF"), Color.parseColor("#0369A1"));
        pdfBtn.setOnClickListener(v -> exportPdf());
        LinearLayout.LayoutParams pdfLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        pdfLp.topMargin = dp(10);
        pdfLp.bottomMargin = dp(4);
        saved.addView(pdfBtn, pdfLp);

        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        saved.addView(listBox);
        LinearLayout.LayoutParams slp = cardLp();
        slp.bottomMargin = dp(24);
        root.addView(saved, slp);

        tts = new TextToSpeech(this, st -> {
            if (st == TextToSpeech.SUCCESS) ttsReady = VoiceUtil.apply(tts);
        });

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.addView(root);
        setContentView(sv);
    }

    @Override protected void onResume() {
        super.onResume();
        boolean conn = WordAccessibilityService.connected;
        statusPill.setText(conn ? "✅  Accessibility চালু আছে" : "⚠️  Accessibility এখনও চালু হয়নি");
        statusPill.setTextColor(Color.parseColor(conn ? "#276749" : "#C05621"));
        statusPill.setBackground(rounded(Color.parseColor(conn ? "#C6F6D5" : "#FEEBC8"), 20));
        accBtn.setVisibility(conn ? View.GONE : View.VISIBLE);
        binding = true;
        sw.setChecked(ToggleTileService.isOn(this));
        binding = false;
        ToggleTileService.refresh(this);
        refreshList();
        // show the setup video only while Accessibility is not enabled
        if (conn) {
            videoCard.setVisibility(View.GONE);
            if (video != null) video.pause();
        } else {
            videoCard.setVisibility(View.VISIBLE);
            if (video != null) video.start();
        }
    }

    @Override protected void onPause() {
        super.onPause();
        if (video != null && video.isPlaying()) video.pause();
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    private void confirm(String msg, Runnable ok) {
        new AlertDialog.Builder(this)
                .setMessage(msg)
                .setPositiveButton("মুছুন", (d, w) -> { ok.run(); refreshList(); })
                .setNegativeButton("না", null)
                .show();
    }

    private void speak(String word) {
        if (tts != null && ttsReady) tts.speak(word, TextToSpeech.QUEUE_FLUSH, null, "ml");
    }

    private void refreshList() {
        listBox.removeAllViews();
        List<SavedWords.Item> items = SavedWords.list(this);
        if (items.isEmpty()) {
            countTv.setText("");
            TextView e = text("এখনও কোনো শব্দ সেভ হয়নি।\nশব্দ সিলেক্ট করলে এখানে নিজে নিজে জমা হবে।\nReading Creator-এ শব্দ সিলেক্ট করে 💾 সেভ চাপলেও জমা হবে।", 14, Color.parseColor("#A0AEC0"), false);
            e.setGravity(Gravity.CENTER);
            e.setPadding(0, dp(18), 0, dp(10));
            listBox.addView(e);
            return;
        }
        countTv.setText("মোট " + items.size() + "টি");

        String today = SavedWords.dayKey(System.currentTimeMillis());
        String lastDay = "";
        for (SavedWords.Item it : items) {
            final String day = SavedWords.dayKey(it.time);
            if (!day.equals(lastDay)) {
                lastDay = day;
                LinearLayout h = new LinearLayout(this);
                h.setOrientation(LinearLayout.HORIZONTAL);
                h.setGravity(Gravity.CENTER_VERTICAL);
                h.setPadding(0, dp(14), 0, dp(2));
                h.addView(text(day.equals(today) ? "আজ  •  " + day : day, 14, Color.parseColor("#4A5568"), true),
                        new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
                TextView dd = text("এই দিনের সব মুছুন", 12, Color.parseColor("#C53030"), true);
                dd.setPadding(dp(10), dp(6), dp(10), dp(6));
                dd.setBackground(rounded(Color.parseColor("#FFF5F5"), 12));
                dd.setOnClickListener(v -> confirm(day + " তারিখের সব শব্দ মুছে ফেলবেন?", () -> SavedWords.removeDay(this, day)));
                h.addView(dd);
                listBox.addView(h);
            }

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(14), dp(8), dp(4), dp(8));
            row.setBackground(rounded(Color.parseColor("#F7FAFC"), 14));
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            rlp.topMargin = dp(6);

            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.addView(text(it.word, 18, BLUE, true));
            if (!it.pron.isEmpty()) col.addView(text("উচ্চারণ: " + it.pron, 13, Color.parseColor("#718096"), false));
            col.addView(text(it.meaning, 16, Color.parseColor("#2D3748"), false));
            row.addView(col, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

            final String word = it.word;
            col.setOnClickListener(v -> speak(word));

            ImageButton mic = new ImageButton(this);
            mic.setImageResource(R.drawable.ic_mic);
            mic.setBackgroundColor(Color.TRANSPARENT);
            mic.setContentDescription("Pronounce");
            mic.setOnClickListener(v -> speak(word));
            row.addView(mic, new LinearLayout.LayoutParams(dp(44), dp(44)));

            ImageButton del = new ImageButton(this);
            del.setImageResource(R.drawable.ic_close);
            del.setBackgroundColor(Color.TRANSPARENT);
            del.setContentDescription("Delete");
            del.setOnClickListener(v -> { SavedWords.remove(this, word); refreshList(); });
            row.addView(del, new LinearLayout.LayoutParams(dp(44), dp(44)));

            listBox.addView(row, rlp);
        }

        TextView all = pillButton("🗑  সব শব্দ মুছুন", Color.parseColor("#FFF5F5"), Color.parseColor("#C53030"));
        all.setOnClickListener(v -> confirm("সব সেভ করা শব্দ মুছে ফেলবেন?", () -> SavedWords.clear(this)));
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        alp.topMargin = dp(16);
        listBox.addView(all, alp);
    }

    /** Compact vocabulary PDF: many words per page, ~2 lines each (EN + BN pron / meaning). */
    private void exportPdf() {
        List<SavedWords.Item> items = SavedWords.list(this);
        if (items.isEmpty()) {
            Toast.makeText(this, "কোনো শব্দ সেভ নেই", Toast.LENGTH_SHORT).show();
            return;
        }

        final int pageW = 595;   // A4 points
        final int pageH = 842;
        final int margin = 24;
        final float gutter = 10f;
        final float colW = (pageW - margin * 2 - gutter) / 2f;
        final float line1Size = 8.5f;
        final float line2Size = 7.5f;
        final float entryH = line1Size + line2Size + 5f;

        PdfDocument doc = new PdfDocument();
        Paint pNum = new Paint(Paint.ANTI_ALIAS_FLAG);
        pNum.setColor(Color.parseColor("#718096"));
        pNum.setTextSize(7f);

        Paint pWord = new Paint(Paint.ANTI_ALIAS_FLAG);
        pWord.setColor(Color.parseColor("#1A365D"));
        pWord.setTextSize(line1Size);
        pWord.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));

        Paint pMeta = new Paint(Paint.ANTI_ALIAS_FLAG);
        pMeta.setColor(Color.parseColor("#4A5568"));
        pMeta.setTextSize(line2Size);

        Paint pHeader = new Paint(Paint.ANTI_ALIAS_FLAG);
        pHeader.setColor(Color.parseColor("#2B6CB0"));
        pHeader.setTextSize(11);
        pHeader.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));

        Paint pSmall = new Paint(Paint.ANTI_ALIAS_FLAG);
        pSmall.setColor(Color.parseColor("#718096"));
        pSmall.setTextSize(7.5f);

        Paint pLine = new Paint();
        pLine.setColor(Color.parseColor("#E2E8F0"));
        pLine.setStrokeWidth(0.5f);

        Paint pColDiv = new Paint();
        pColDiv.setColor(Color.parseColor("#CBD5E1"));
        pColDiv.setStrokeWidth(0.7f);

        String dateStr = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date());
        String title = "Word Helper — সেভ করা শব্দ (" + items.size() + "টি)";

        // Precompute how many rows fit per page (after header)
        float headerH = 44f;
        float contentBottom = pageH - margin - 14;
        int rowsPerPage = Math.max(1, (int) ((contentBottom - (margin + headerH)) / entryH));
        int slotsPerPage = rowsPerPage * 2; // two columns

        int total = items.size();
        int pageNum = 0;
        int idx = 0;

        while (idx < total) {
            pageNum++;
            PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(pageW, pageH, pageNum).create();
            PdfDocument.Page page = doc.startPage(info);
            Canvas canvas = page.getCanvas();

            float y = margin;
            canvas.drawText(title, margin, y + 11, pHeader);
            y += 16;
            canvas.drawText("তৈরি: " + dateStr + "  ·  নম্বর · ইংরেজি · উচ্চারণ · অর্থ  (বাম+ডান কলাম)", margin, y + 9, pSmall);
            y += 14;
            canvas.drawLine(margin, y, pageW - margin, y, pLine);
            y += 8;
            float topY = y;

            // vertical divider between columns
            float midX = margin + colW + gutter / 2f;
            canvas.drawLine(midX, topY - 4, midX, contentBottom, pColDiv);

            for (int row = 0; row < rowsPerPage && idx < total; row++) {
                for (int col = 0; col < 2 && idx < total; col++) {
                    SavedWords.Item it = items.get(idx);
                    int num = idx + 1;
                    idx++;

                    float x0 = margin + col * (colW + gutter);
                    float ey = topY + row * entryH;

                    String w = it.word == null ? "" : it.word;
                    String pr = it.pron == null ? "" : it.pron;
                    String m = it.meaning == null ? "" : it.meaning;

                    String numStr = num + ".";
                    canvas.drawText(numStr, x0, ey + line1Size, pNum);
                    float numW = pNum.measureText(numStr + " ");

                    // word (trim to column)
                    String wordDraw = w;
                    float maxWordW = colW - numW - 2;
                    while (pWord.measureText(wordDraw) > maxWordW && wordDraw.length() > 2) {
                        wordDraw = wordDraw.substring(0, wordDraw.length() - 1);
                    }
                    if (!wordDraw.equals(w) && wordDraw.length() > 1) wordDraw = wordDraw.substring(0, wordDraw.length() - 1) + "…";
                    canvas.drawText(wordDraw, x0 + numW, ey + line1Size, pWord);

                    String line2 = (pr.isEmpty() ? "" : ("[" + pr + "] ")) + m;
                    float maxW = colW - 2;
                    while (pMeta.measureText(line2) > maxW && line2.length() > 4) {
                        line2 = line2.substring(0, line2.length() - 2);
                    }
                    if (pMeta.measureText(line2) > maxW && line2.length() > 1) {
                        line2 = line2.substring(0, Math.max(1, line2.length() - 1)) + "…";
                    }
                    canvas.drawText(line2, x0, ey + line1Size + line2Size + 1.5f, pMeta);

                    // light bottom line under each cell
                    canvas.drawLine(x0, ey + entryH - 1.5f, x0 + colW, ey + entryH - 1.5f, pLine);
                }
            }

            canvas.drawText("পৃষ্ঠা " + pageNum, pageW / 2f - 18, pageH - 12, pSmall);
            doc.finishPage(page);
        }

        String fileName = "WordHelper_vocab_" +
                new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".pdf";

        try {
            Uri uri = writePdfToDownloads(doc, fileName);
            doc.close();
            if (uri != null) {
                Toast.makeText(this, "PDF সেভ হয়েছে: Downloads/" + fileName, Toast.LENGTH_LONG).show();
                try {
                    Intent view = new Intent(Intent.ACTION_VIEW);
                    view.setDataAndType(uri, "application/pdf");
                    view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(view, "PDF খুলুন"));
                } catch (Exception openEx) {
                    // file is saved even if no viewer
                }
            } else {
                Toast.makeText(this, "PDF সেভ ব্যর্থ", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            try { doc.close(); } catch (Exception ignored) {}
            Toast.makeText(this, "PDF ত্রুটি: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private Uri writePdfToDownloads(PdfDocument doc, String fileName) throws Exception {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
            values.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) return null;
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null) return null;
                doc.writeTo(out);
            }
            return uri;
        } else {
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (!dir.exists()) dir.mkdirs();
            File f = new File(dir, fileName);
            try (FileOutputStream out = new FileOutputStream(f)) {
                doc.writeTo(out);
            }
            // notify media scanner
            Intent scan = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
            scan.setData(Uri.fromFile(f));
            sendBroadcast(scan);
            return Uri.fromFile(f);
        }
    }
}
