package com.bnword.helper;

import java.util.ArrayList;
import java.util.List;

/** Converts an IPA transcription (as given by dictionaries) into Bengali-script pronunciation. */
final class IpaBn {
    private static final String[][] CONS = {
        {"tʃ","চ"},{"dʒ","জ"},{"ʧ","চ"},{"ʤ","জ"},{"ʃ","শ"},{"ʒ","জ"},{"θ","থ"},{"ð","দ"},
        {"ŋ","ং"},{"p","প"},{"b","ব"},{"t","ট"},{"d","ড"},{"k","ক"},{"ɡ","গ"},{"g","গ"},
        {"f","ফ"},{"v","ভ"},{"s","স"},{"z","জ"},{"h","হ"},{"m","ম"},{"n","ন"},{"l","ল"},
        {"ɫ","ল"},{"r","র"},{"ɹ","র"},{"ɾ","র"},{"j","য়"},{"w","ও"},{"x","খ"},{"ʔ",""},{"ɲ","ন"}
    };
    // {ipa, independent form, sign form after a consonant}
    private static final String[][] VOW = {
        {"juː","ইউ","িউ"},{"ju","ইউ","িউ"},
        {"ɜːɹ","আর","ার"},{"ɜːr","আর","ার"},{"ɜː","আর","ার"},{"ɝ","আর","ার"},{"ɚ","আর","ার"},
        {"aɪ","আই","াই"},{"eɪ","এই","েই"},{"ɔɪ","অয়","য়"},{"aʊ","আউ","াউ"},
        {"oʊ","ও","ো"},{"əʊ","ও","ো"},{"ɪə","ইয়া","িয়া"},{"eə","এয়ার","েয়ার"},{"ɛə","এয়ার","েয়ার"},{"ʊə","উয়ার","ুয়ার"},
        {"iː","ই","ি"},{"uː","উ","ু"},{"ɑː","আ","া"},{"ɔː","অ",""},{"ɒː","অ",""},
        {"i","ই","ি"},{"ɪ","ই","ি"},{"ɨ","ই","ি"},{"ᵻ","ই","ি"},
        {"ɛ","এ","ে"},{"e","এ","ে"},{"æ","অ্যা","্যা"},{"a","অ্যা","্যা"},
        {"ɑ","আ","া"},{"ɒ","অ",""},{"ɔ","অ",""},{"ʊ","উ","ু"},{"u","উ","ু"},{"ʉ","উ","ু"},
        {"ʌ","আ","া"},{"ɐ","আ","া"},{"ə","অ্যা","ে"},{"ɵ","ও","ো"},{"o","ও","ো"}
    };

    private static final class Tok { boolean vowel; String ind, sign, cons; }

    private static String clean(String ipa) {
        String s = ipa.replaceAll("[/\\[\\]()ˈˌ.‿\\s'\\-]", "");
        s = s.replace("ʃən", "ʃn").replace("ʒən", "ʒn").replace("ɪŋ", "ɪŋ");
        return s;
    }

    static String convert(String ipa) { return convert(ipa, null); }

    static String convert(String ipa, String word) {
        if (ipa == null) return null;
        String s = clean(ipa);
        if (s.isEmpty()) return null;
        List<Tok> toks = new ArrayList<>();
        int i = 0;
        outer:
        while (i < s.length()) {
            if (s.charAt(i) == 'ː') { i++; continue; }
            for (String[] v : VOW) {
                if (s.startsWith(v[0], i)) {
                    Tok t = new Tok(); t.vowel = true; t.ind = v[1]; t.sign = v[2];
                    t.cons = v[0];
                    toks.add(t); i += v[0].length(); continue outer;
                }
            }
            for (String[] c : CONS) {
                if (s.startsWith(c[0], i)) {
                    Tok t = new Tok(); t.vowel = false; t.cons = c[1]; t.ind = c[0];
                    toks.add(t); i += c[0].length(); continue outer;
                }
            }
            i++; // unknown symbol, skip
        }
        StringBuilder out = new StringBuilder();
        boolean prevCons = false;    // last emitted thing is a consonant letter (can take a vowel sign)
        boolean prevHasant = false;  // last emitted a hasant
        for (int k = 0; k < toks.size(); k++) {
            Tok t = toks.get(k);
            boolean first = out.length() == 0;
            boolean last = (k == toks.size() - 1);
            Tok next = last ? null : toks.get(k + 1);
            if (t.vowel) {
                if (t.ind.equals("ইউ") && t.sign.equals("িউ")) {
                    out.append(prevCons ? t.sign : t.ind);
                } else if (t.cons.equals("ə")) {
                    boolean erEnd = last && word != null
                            && word.toLowerCase().matches(".*(er|or|ar|ur|our|re|ors|ers|ars)$");
                    if (!prevCons) out.append(t.ind);
                    else if (erEnd) out.append("ার");
                    else out.append(last ? "া" : "ে");
                } else {
                    out.append(prevCons ? t.sign : t.ind);
                }
                // r-coloured vowels followed by a consonant: ার্ড style
                if (t.sign.endsWith("র") && next != null && !next.vowel && !next.cons.equals("ং")) {
                    out.append("্");
                    prevCons = false; prevHasant = true;
                } else {
                    prevCons = false; prevHasant = false;
                }
                // a vowel sign ends the syllable; independent vowels too
                continue;
            }
            // consonant
            String c = t.cons;
            if (c.isEmpty()) continue;
            if (c.equals("ং")) { out.append("ং"); prevCons = false; prevHasant = false; continue; }
            if (t.ind.equals("j")) {
                // y sound
                if (first || !prevCons) {
                    out.append("ইয়");
                    prevCons = true; prevHasant = false;
                } else {
                    out.append("য়");
                    prevCons = true; prevHasant = false;
                }
                continue;
            }
            if (t.ind.equals("w")) {
                if (first || !prevCons) { out.append("ওয়"); prevCons = true; prevHasant = false; }
                else { out.append("ু"); out.append("য়"); prevCons = true; prevHasant = false; }
                continue;
            }
            // join two consonants with hasant (conjunct)
            if (prevCons && !prevHasant) { out.append("্"); }
            out.append(c);
            prevCons = true; prevHasant = false;
            // reph: r after a vowel, before another consonant:  চার্ট
            if (t.ind.equals("r") || t.ind.equals("ɹ") || t.ind.equals("ɾ")) {
                boolean afterVowel = k > 0 && toks.get(k - 1).vowel;
                if (afterVowel && next != null && !next.vowel && !next.cons.equals("ং")) {
                    out.append("্");
                    prevCons = false; prevHasant = true;
                }
            }
        }
        String r = out.toString();
        // a trailing hasant looks wrong
        while (r.endsWith("্")) r = r.substring(0, r.length() - 1);
        return r.isEmpty() ? null : r;
    }
}
