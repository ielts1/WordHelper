package com.bnword.helper;

import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;

import java.util.Locale;

/** Sets up a fuller, more natural-sounding English voice. */
public class VoiceUtil {
    /** @return true if English is usable. */
    public static boolean apply(TextToSpeech tts) {
        int r = tts.setLanguage(Locale.US);
        boolean ok = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
        if (!ok) return false;
        try {
            Voice best = null;
            for (Voice v : tts.getVoices()) {
                if (v.getLocale() == null) continue;
                if (!"en".equals(v.getLocale().getLanguage()) || !"US".equals(v.getLocale().getCountry())) continue;
                if (v.getFeatures() != null && v.getFeatures().contains("notInstalled")) continue;
                if (best == null || score(v) > score(best)) best = v;
            }
            if (best != null) tts.setVoice(best);
        } catch (Exception ignored) { }
        tts.setSpeechRate(0.9f);
        tts.setPitch(0.8f); // lower pitch = deeper, less thin voice
        return true;
    }

    private static int score(Voice v) {
        int s = v.getQuality() * 10;               // higher quality first
        if (!v.isNetworkConnectionRequired()) s += 5; // offline voices are reliable
        s -= v.getLatency() / 100;
        return s;
    }
}
